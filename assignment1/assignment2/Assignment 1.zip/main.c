//
//  main.c
//  assignment
//
//  Created by mac on 2020/5/14.
//  Copyright © 2020 mac. All rights reserved.


/**
 * Sample test routine for executing each function at least once.
 * Copyright Brian Fraser, 2020
 */

#include "list.h"
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>

// Macro for custom testing; does exit(1) on failure.
#define CHECK(condition) do{ \
    if (!(condition)) { \
        printf("ERROR: %s (@%d): failed condition \"%s\"\n", __func__, __LINE__, #condition); \
        exit(1);\
    }\
} while(0)


//
// For checking the "free" function called
static int complexTestFreeCounter = 0;
static void complexTestFreeFn(void* pItem)
{
    CHECK(pItem != NULL);
    complexTestFreeCounter++;
}

// For searching
static bool itemEquals(void* pItem, void* pArg)
{
    return (pItem == pArg);
}

static void testComplex()
{
   //  Empty list
    List* pLista = List_create();
    CHECK(pLista != NULL);
    CHECK(List_count(pLista) == 0);

   //  Add
    int added = 41;
    CHECK(List_add(pLista, &added) == 0);
    CHECK(List_count(pLista) == 1);
    CHECK(List_curr(pLista) == &added);


    int b=5;
    CHECK(List_add(pLista, &b)==0);
    CHECK(List_count(pLista) == 2);
    CHECK(List_curr(pLista) == &b);

    int c=6;
    CHECK(List_add(pLista, &c)==0);
    CHECK(List_count(pLista) == 3);
    CHECK(List_curr(pLista) == &c);

    int d=10;
    CHECK(List_add(pLista, &d)==0);
    CHECK(List_count(pLista) == 4);
    CHECK(List_curr(pLista) == &d);
    List_next(pLista);                   // at the beyond of tail
    
    int e=11;
    CHECK(List_add(pLista, &e)==0);
    CHECK(List_count(pLista) == 5);
    CHECK(List_curr(pLista) == &e);
    CHECK(List_first(pLista)==&added);
    List_prev(pLista);                   // at the before of head
    
    int f=12;
    CHECK(List_add(pLista, &f)==0);
    CHECK(List_count(pLista) == 6);
    CHECK(List_curr(pLista) == &f);
    
   //Insert
   // List* pList;                  //test for empty
    List* pListb = List_create();
    int inserted = 42;
    CHECK(List_insert(pListb, &inserted) == 0);
    CHECK(List_count(pListb) == 1);
    CHECK(List_curr(pListb) == &inserted);
    
    int i2 = 43;
    CHECK(List_insert(pListb, &i2) == 0);
    CHECK(List_count(pListb) == 2);
    CHECK(List_curr(pListb) == &i2);

    int i3 = 44;
    CHECK(List_insert(pListb, &i3) == 0);
    CHECK(List_count(pListb) == 3);
    CHECK(List_curr(pListb) == &i3);

    int i4 = 45;
    CHECK(List_insert(pListb, &i4) == 0);
    CHECK(List_count(pListb) == 4);
    CHECK(List_curr(pListb) == &i4);             // at the before of head
    List_prev(pListb);
    
    int i5 = 46;
    CHECK(List_insert(pListb, &i5) == 0);
    CHECK(List_count(pListb) == 5);
    CHECK(List_curr(pListb) == &i5);
    
    CHECK(List_last(pListb)==&inserted);
    
    
    int i6 = 47;                                 // at the end r
    CHECK(List_insert(pListb, &i6) == 0);
    CHECK(List_count(pListb) == 6);
    CHECK(List_curr(pListb) == &i6);
    
    CHECK(List_last(pListb)==&inserted);
    List_next(pListb);                               // at the beyond of tail
    
    
    int i7 = 48;
    CHECK(List_insert(pListb, &i7) == 0);
    CHECK(List_count(pListb) == 7);
    CHECK(List_curr(pListb) == &i7);
    
    
    List_concat(pLista, pListb);                      // merge them
    CHECK(List_count(pLista) == 13);
    CHECK(List_first(pLista) == &f);
    CHECK(List_last(pLista) == &i7);
    
    complexTestFreeCounter = 0;                     // free the pLista
    List_free(pLista, complexTestFreeFn);
    CHECK(complexTestFreeCounter == 13);

//
//    complexTestFreeCounter = 0;                     // free the pListb
//    List_free(pListb, complexTestFreeFn);
//    CHECK(complexTestFreeCounter == 7);
    
    
    
    // Empty list
    List* pList = List_create();
    CHECK(pList != NULL);
    CHECK(List_count(pList) == 0);
//
    // Add
    int add = 41;
    CHECK(List_add(pList, &add) == 0);
    CHECK(List_count(pList) == 1);
    CHECK(List_curr(pList) == &add);
//
    // Insert
    int insert = 42;
    CHECK(List_insert(pList, &insert) == 0);
    CHECK(List_count(pList) == 2);
    CHECK(List_curr(pList) == &insert);

    // Prepend
    int prepended = 43;
    CHECK(List_prepend(pList, &prepended) == 0);
    CHECK(List_count(pList) == 3);
    CHECK(List_curr(pList) == &prepended);
//
   //  Append
    int appended = 44;
    CHECK(List_append(pList, &appended) == 0);
    CHECK(List_count(pList) == 4);
    CHECK(List_curr(pList) == &appended);

    // Next through it all (from before list)
    CHECK(List_first(pList) == &prepended);
    CHECK(List_prev(pList) == NULL);
    CHECK(List_next(pList) == &prepended);
    CHECK(List_next(pList) == &insert);
    CHECK(List_next(pList) == &add);
    CHECK(List_next(pList) == &appended);
    CHECK(List_next(pList) == NULL);
    CHECK(List_next(pList) == NULL);

    // Prev through it all
    //   starting from past end
    CHECK(List_last(pList) == &appended);
    CHECK(List_next(pList) == NULL);
    CHECK(List_prev(pList) == &appended);
    CHECK(List_prev(pList) == &add);
    CHECK(List_prev(pList) == &insert);
    CHECK(List_prev(pList) == &prepended);
    CHECK(List_prev(pList) == NULL);
    CHECK(List_prev(pList) == NULL);

    // Remove first
    CHECK(List_first(pList) == &prepended);
    CHECK(List_remove(pList) == &prepended);
    CHECK(List_curr(pList) == &insert);
//
    // Trim last
    CHECK(List_trim(pList) == &appended);
    CHECK(List_curr(pList) == &add);

    // Free remaining 2 elements
    complexTestFreeCounter = 0;
    List_free(pList, complexTestFreeFn);
    CHECK(complexTestFreeCounter == 2);
////
////
 //    Concat
    int one = 1;
    int two = 2;
    int three = 3;
    int four = 4;
    List* pList1 = List_create();
    List_add(pList1, &one);
    List_add(pList1, &two);
    List* pList2 = List_create();
    
    List_add(pList2, &three);
    List_add(pList2, &four);

    List_concat(pList1, pList2);
    CHECK(List_count(pList1) == 4);
    CHECK(List_first(pList1) == &one);
    CHECK(List_last(pList1) == &four);

//
    // Search
    List_first(pList);
    CHECK(List_search(pList, itemEquals, &two) == &two);
    CHECK(List_search(pList, itemEquals, &two) == &two);
    CHECK(List_search(pList, itemEquals, &one) == NULL);
}
int main(int argCount, char *args[])
{
    testComplex();

    // We got here?!? PASSED!
    printf("********************************\n");
    printf("           PASSED\n");
    printf("********************************\n");
    return 0;

}




#include <linux/kernel.h>
#include <linux/syscalls.h>
#include <linux/sched.h>

#define ANCESTOR_NAME_LEN 16
struct process_info {
    long pid;                         /* Process ID */
    char name[ANCESTOR_NAME_LEN];     /* Program name of process */
    long state;                       /* Current process state */
    long uid;                         /* User ID of process owner */
    long nvcsw;                       /* # voluntary context switches */
    long nivcsw;                      /* # involuntary context switches */
    long num_children;                /* # children process has */
    long num_siblings;                /* # sibling process has */
};

SYSCALL_DEFINE3(
    process_ancestors,                /* syscall name for macro */
    struct process_info*, info_array, /* array of process info strct */
    long, size,                       /* size of the array */
    long*, num_filled )               /* # elements written to array */
{
      // your code here...
    struct process_info temp;
    struct process_info * temp_use = &temp;
    struct task_struct* curr_task;
    struct list_head *list;
    int i,j;

    long temp_size;
    long* used_size;                         // it is num_filled back to user level
    
    long count_children, count_sibling=0;
    curr_task = current;
    temp_size = 0;
    used_size = &temp_size;
    
    if (size<=0){
        printk(" Invail size !!!");
        return -EINVAL;
    }
    if (info_array == NULL ||num_filled == NULL){
        printk(" Invail Pointer ");
        return -EFAULT;
    }

    for (i = 0; curr_task->parent!=curr_task; i++){
        for (j=0; j<ANCESTOR_NAME_LEN; j++)
            temp_use->name[j] = curr_task->comm[j];
        temp_use->pid = curr_task->pid;
        temp_use->state = curr_task->state;
        temp_use->nvcsw = curr_task->nvcsw;
        temp_use->nivcsw = curr_task->nivcsw;
        temp_use->uid = curr_task->cred->uid.val;

        list_for_each(list, &curr_task->children){
            count_children++;
        }
        temp_use->num_children = count_children;
        list_for_each(list, &curr_task->sibling){
            count_sibling++;
        }
        temp_use->num_siblings = count_sibling;
        if (copy_to_user(&(info_array[i]), &temp, sizeof(temp))){
            printk(" Copy array element problem!! ");
            return -EFAULT;
        }
        curr_task = curr_task->parent ;
        used_size = used_size + 1;
    }
    if (copy_to_user(num_filled , &used_size , sizeof(long))){
        printk(" Copy size problem \n");
        return -EFAULT;
    }
    return 0;

}

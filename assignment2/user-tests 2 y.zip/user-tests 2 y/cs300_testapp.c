#include <stdio.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <errno.h> // For errno global
#define _CS300_TEST_ 548 
int main(int argc, char *argv[])
{
	printf("\nDiving to kernel level\n\n");
	int result = syscall(_CS300_TEST_ , 12345);
// Get the error code (if any)
// errno is when a syscall or some library function has an error
// when syscall returns -1, then check errno for specific error
	int errorCode = errno;
	printf("\nRising to user level w/ result = %d (err #%d)\n\n", result, errorCode);
	return 0;
}

#include <linux/kernel.h>
#include <linux/syscalls.h>
#include <linux/sched.h>

#define ANCESTOR_NAME_LEN 16
struct process_info {
    long pid;                         /* Process ID */
    char name[ANCESTOR_NAME_LEN];     /* Program name of process */
    long state;                       /* Current process state */
    long uid;                         /* User ID of process owner */
    long nvcsw;                       /* # voluntary context switches */
    long nivcsw;                      /* # involuntary context switches */
    long num_children;                /* # children process has */
    long num_siblings;                /* # sibling process has */
};

SYSCALL_DEFINE3(
    process_ancestors,                /* syscall name for macro */
    struct process_info*, info_array, /* array of process info strct */
    long, size,                       /* size of the array */
    long*, num_filled )               /* # elements written to array */
{
      // your code here...
    struct list_head* child_list;
    struct list_head* sibling_list;
    struct task_struct* current_task = current;
    int temp_pid = 0;
    char temp_name = '';
    int temp_state = 0;
    int temp_uid = 0;
    int temp_nvcsw = 0;
    int temp_nivcsw = 0;
    int temp_num_children = 0;
    int temp_num_subling = 0;
    int temp_filled = 0;
    int count = 0;
    int i = 0;
    
                                                                //fail case
    if (size<=0){
        printk(" Invail size !!!");
        return -EINVAL;
    }
    if (info_array == NULL ||num_filled == NULL){
        printk(" Invail Pointer ");
        return -EFAULT;
    }
                                                            // using loop for coping each elements
    for (i = 0; i< size; i++)
    {
        list_for_each(child_list,&(current_task->children)){
            temp_num_children++;
        }
        list_for_each(sibling_list , &(current_task->sibling)){
            temp_num_subling++;
        }
        finish_pid = (long)current_task->pid;
        finish_state = (long) current_task->state;
    
        temp_name = copy_to_user(&(info_array[i].name),&current_task->comm,ANCESTOR_NAME_LEN * sizeof(char));
        if (temp_name ! = NULL){
            printk(" copy name fail");
            return -EFAULT;
        }
        temp_pid = copy_to_user(&(info_array[i].pid),&finish_pid , sizeof(long));
        if (temp_pid ! = 0){
            printk(" copy PID fail");
            return -EFAULT;
        }
        temp_state= copy_to_user(&(info_array[i].state),&finish_state,sizeof(long));
        if (temp_state ! = 0){
            printk(" copy state fail");
            return -EFAULT;
        }
        temp_uid = copy_to_user(&(info_array[i].uid),&current_task->cred->uid.val,sizeof(long));
        if (temp_uid ! = 0){
            printk(" copy UID fail");
            return -EFAULT;
        }
        temp_nvcsw = copy_to_user(&(info_array[i].nvcsw),&current-task_struct->nvcsw,sizeof(long));
        if (temp_nvcsw ! = 0){
            printk(" copy NVCSW fail");
            return -EFAULT;
        }
        temp_nivcsw = copy_to_user(&(info_array[i].nivcsw),&current_task->nivcsw,sizeof(long));
        if (temp_nivcsw ! = 0){
            printk(" copy NIVCSW fail");
            return -EFAULT;
        }
        temp_num_children = copy_to_user(&(info_array[i].num_children), &num_children, sizeof(long));
        if (temp_num_children ! = 0){
            printk(" copy number of children fail");
            return -EFAULT;
        }
        temp_num_subling = copy_to_user(&(info_array[i].num_siblings), &num_siblings, sizeof(long));
        if (temp_num_subling ! = 0){
            printk(" copy number of sublings fail");
            return -EFAULT;
        }
        count++;
        num_children = 0;
        num_siblings = 0;
        if (current_task->parent ==current_task)
            break;
        current_task = current_task->parent;
    }
    
    temp_filled = copy_to_user(num_filled , &filled , sizeof(long));
    if (temp_filled!=0){
        printk(" copy filled fail");
            return -EFAULT;
        }
    return 0;
}

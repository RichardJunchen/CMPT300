#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/syscall.h>
#include <errno.h>

#define SYSCALL_ASS2_TEST 550
#define SIZE 100 
#define ANCESTOR_NAME_LEN 16

struct process_info {
    long pid;                         /* Process ID */
    char name[ANCESTOR_NAME_LEN];     /* Program name of process */
    long state;                       /* Current process state */
    long uid;                         /* User ID of process owner */
    long nvcsw;                       /* # voluntary context switches */
    long nivcsw;                      /* # involuntary context switches */
    long num_children;                /* # children process has */
    long num_siblings;                /* # sibling process has */
};

int main(int argc, char * argv[]){
    long size = 0;
    long * actual_copy = &size;
    struct process_info information_array[SIZE];
    printf(" Changing into the kernel level \n\n");
    int result = syscall(SYSCALL_ASS2_TEST, information_array, SIZE, actual_copy);
    int errorCode = errno;
    printf("Back into the user level \n");
    if (result < 0){
        printf("\n The user level result =%d (error #%d)\n", result, errorCode);
        printf(" Wrong!!! Please check all input again \n " );
    }
    else{
        printf("\n The user level result =%d (error #%d)\n",result, errorCode);
        printf("Just a example : \n");
        printf("The second process name is %s, pid is %ld, state is %ld, uid is %ld, nvcsw is %ld, nivcsw is %ld \n", information_array[1].name, information_array[1].pid,information_array[1].state, information_array[1].uid,information_array[1].nvcsw,information_array[1].nivcsw);
        printf("It has %ld children and %ld siblings \n", information_array[1].num_children,information_array[1].num_siblings);
    }
    return 0;
}
